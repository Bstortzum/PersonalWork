// Brian Stortzum
// 04/08/2025
// This program is for Lab 6 and it shows the basic knowledge of OOP

#include <iostream>
#include <iomanip>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <string>
#include "bstortzum_Lab6.h"
using namespace std;

// Function prototypes
void displayTitle();
ifstream openInFile();
void inputData(vector<Employees>& empVec);
void sortByLastName(vector<Employees>& empVec);
void displayEmp(const vector<Employees>& empVec);
void findEmp(vector<Employees>& empVec);

int main() 
{
    // Set fixed output formatting for decimals.
    cout << fixed << setprecision(2) << showpoint;

    // Displays title
    displayTitle();
    
    // Creates a empty vector
    vector<Employees> empData;

    // Read employee data from file.
    inputData(empData);

    // Sort the vector by last name using a selection sort algorithm.
    sortByLastName(empData);

    // Display the sorted employee information.
    displayEmp(empData);

    // Find the employee with the last name "Girma" and, if found and units sold equals 99,
    findEmp(empData);

    // Clear the vector.
    empData.clear();

    cout << "\nThank you for using the program\n";
    system("pause");
    return 0;
}

// Displays the program title and introduction.
void displayTitle() 
{
    cout << "IS-241 Lab 6 - Object Oriented Coding\n";
    cout << "This program reads an employee file and displays the data sorted by last name.\n\n";
}

// Prompts the user to enter the file name and opens the file.
ifstream openInFile()
{
    string fName;
    ifstream fHandle;
    do
    {
        cout << "Enter input file name and path: ";
        getline(cin, fName);
        fHandle.open(fName);
        if (!fHandle)
        {
            cout << "Error - File could not be found. Please Reenter\n\n";
        }
    } while (!fHandle);

    return fHandle;

}

// Reads employee data from the input file and populates the vector.
void inputData(vector<Employees>& empVec) 
{
    ifstream inFile = openInFile();
    char tempFirst[EMP_NAME_SIZE];
    char tempLast[EMP_NAME_SIZE];
    char NumDaysSold[EMP_NAME_SIZE]; // for reading numeric values
    int days, sold;

    // Read until the end of the file.
    while (inFile.getline(tempFirst, EMP_NAME_SIZE)) 
    {
        inFile.getline(tempLast, EMP_NAME_SIZE);
        inFile.getline(NumDaysSold, EMP_NAME_SIZE);
        days = atoi(NumDaysSold);
        inFile.getline(NumDaysSold, EMP_NAME_SIZE);
        sold = atoi(NumDaysSold);

        // Create an Employees object using the full constructor.
        Employees emp(tempFirst, tempLast, days, sold);
        empVec.push_back(emp);
    }
    inFile.close();
    cout << "\nThe number of Employees read is: " << empVec.size() << "\n\n";
}

// Sorts the vector of Employees objects by the last name using a selection sort algorithm.
void sortByLastName(vector<Employees>& empVec) 
{
    for (int i = 0; i < empVec.size() - 1; i++) 
    {
        int minIndex = i;
        for (int j = i + 1; j < empVec.size(); j++)
        {
            // Compare last names using strcmp and the getLastName() method.
            if (strcmp(empVec[j].getLastName(), empVec[minIndex].getLastName()) < 0) 
            {
                minIndex = j;
            }
        }
        if (minIndex != i) 
        {
            swap(empVec[i], empVec[minIndex]);
        }
    }
}

// Displays each employee's information using a range-based for loop.
void displayEmp(const vector<Employees>& empVec) 
{
    for (const Employees& emp : empVec) 
    {
        emp.displayEmployee();
    }
}

// Searches for an employee with the last name "Girma". If found and if that employee's units sold is 99,
void findEmp(vector<Employees>& empVec) 
{
    bool found = false;
    for (Employees& emp : empVec) 
    {
        if (strcmp(emp.getLastName(), "Girma") == 0) 
        {
            if (emp.getUnitsSold() == 99) 
            {
                emp.setUnitsSold(106);
                cout << "\nUpdated " << emp.getFirstName() << " " << emp.getLastName() << "'s units sold from 99 to " << emp.getUnitsSold() << ".\n";
            }
            found = true;
        }
    }
    if (found) // This is for if the function above finds Girma
    {
        cout << "\nAfter update:\n";
        displayEmp(empVec);
    } 
    else 
    {
        cout << "\nError: No employee with last name 'Girma' found.\n";
    }
}
