// Brian Stortzum
// 04/08/2025
// This program is for Lab 6 and it shows the basic knowledge of OOP
#ifndef BSTORTZUM_LAB6
#define BSTORTZUM_LAB6

#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdlib>
using namespace std;

// Delcare Constant
const int EMP_NAME_SIZE = 24;

// Class declaration
class Employees 
{
private:
    char firstName[EMP_NAME_SIZE] = " ";
    char lastName[EMP_NAME_SIZE] = " ";
    int daysWorked = 0;
    int unitsSold = 0;

    // This calculate the average units sold per day
    double calculateAverage() const;

public:
    // Constructors
    Employees();

    // This constructor uses the setter methods only
    Employees(const char* fName, const char* lName, int days, int sold);

    // Setter method
    void setFirstName(const char* fName);
    void setLastName(const char* lName);
    void setDaysWorked(int days);
    void setUnitsSold(int sold);

    // Getter method
    const char* getFirstName() const;
    const char* getLastName() const;
    int getDaysWorked() const;
    int getUnitsSold() const;

    // Public display method that shows all data along with the average units sold.
    void displayEmployee() const;
};
#endif
