// Brian Stortzum
// 04/08/2025
// This program is for Lab 6 and it shows the basic knowledge of OOP
#include "bstortzum_Lab6.h"
using namespace std;

// Default Constructor
Employees::Employees() 
{
    // Use set methods to initialize data members.
    setFirstName("");
    setLastName("");
    setDaysWorked(0);
    setUnitsSold(0);
}

// Full Constructor
Employees::Employees(const char* fName, const char* lName, int days, int sold) 
{
    setFirstName(fName);
    setLastName(lName);
    setDaysWorked(days);
    setUnitsSold(sold);
}

// Setter for first name
void Employees::setFirstName(const char* fName) 
{
    strncpy_s(firstName, fName, EMP_NAME_SIZE - 1);
    firstName[EMP_NAME_SIZE - 1] = '\0';
}

// Setter for last name
void Employees::setLastName(const char* lName) 
{
    strncpy_s(lastName, lName, EMP_NAME_SIZE - 1);
    lastName[EMP_NAME_SIZE - 1] = '\0';
}

// Setter for days worked
void Employees::setDaysWorked(int days) 
{
    daysWorked = days;
}

// Setter for units sold
void Employees::setUnitsSold(int sold) 
{
    unitsSold = sold;
}

// Getter for first name
const char* Employees::getFirstName() const 
{
    return firstName;
}

// Getter for last name
const char* Employees::getLastName() const 
{
    return lastName;
}

// Getter for days worked
int Employees::getDaysWorked() const 
{
    return daysWorked;
}

// Getter for units sold
int Employees::getUnitsSold() const 
{
    return unitsSold;
}

// This calculate the average number of units sold per day
double Employees::calculateAverage() const 
{
    int days = getDaysWorked();
    int sold = getUnitsSold();
    if (days == 0)
        return 0.0;
    return static_cast<double>(sold) / days;
}

// Public method to display the employee's information
// Uses the get methods and the calculateAverage() method
void Employees::displayEmployee() const 
{
    double avg = calculateAverage();
    cout << "Employee: " << getFirstName() << " " << getLastName()
        << " worked " << getDaysWorked() << " days and sold " << getUnitsSold()
        << " units for an average of " << fixed << setprecision(2) << avg
        << " units per day.\n";
}

