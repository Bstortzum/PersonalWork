// Brian Stortzum
// 04/08/2025
// IS-241 Lab 7 - Advanced OO Design

#include <iostream>
#include "Planet.h"
using namespace std;

int main()
{
    // Create Planet objects
    Planet planet1("Jupiter");
    Planet planet2, planet3, planet4, planet5, planet6;

    // Display title
    cout << "IS-241 Lab 7 - Advanced OO Design" << endl;
    cout << "Welcome to IS-241 Planet Operations Program" << endl << endl;

    // Display planet1 details using getter functions
    cout << "The planet name is: " << planet1.getPlanetName() << endl;
    cout << "The planet number is: " << planet1.getPlanetNumber() << endl;
    cout << "The planet has " << planet1.getNumMoons() << " moons." << endl << endl;

    // Display planet1 details as in the screenshot (simulating the �overloaded streaming operator� output)
    cout << "Using cout and the overloaded streaming operator:" << endl;
    cout << "The planet " << planet1.getPlanetName() << " is planet number: " << planet1.getPlanetNumber() << endl;
    cout << "It has " << planet1.getNumMoons() << " moons." << endl << endl;

    // Use the prefix ++ operator
    cout << "Using the prefix operator for planet1 and planet2:" << endl;
    planet2 = ++planet1;
    cout << "The planet " << planet1.getPlanetName() << " is planet number: " << planet1.getPlanetNumber() << endl;
    cout << "It has " << planet1.getNumMoons() << " moons." << endl;
    cout << "The planet " << planet2.getPlanetName() << " is planet number: " << planet2.getPlanetNumber() << endl;
    cout << "It has " << planet2.getNumMoons() << " moons." << endl << endl;

    // Use the postfix ++ operator
    cout << "Using the postfix operator for planet1 and planet3:" << endl;
    planet3 = planet1++;  

    cout << "The planet " << planet1.getPlanetName() << " is planet number: " << planet1.getPlanetNumber() << endl;
    cout << "It has " << planet1.getNumMoons() << " moons." << endl;
    
    planet1++;

    cout << "The planet " << planet3.getPlanetName() << " is planet number: " << planet3.getPlanetNumber() << endl;
    cout << "It has " << planet3.getNumMoons() << " moons." << endl << endl;

    // Overloaded input operator for planet4
    cout << "Using the overloaded input streaming operator for Planet 4:" << endl;
    cin >> planet4;
    cout << "The planet " << planet4.getPlanetName() << " is planet number: " << planet4.getPlanetNumber() << endl;
    cout << "It has " << planet4.getNumMoons() << " moons." << endl << endl;

    // Overloaded '-' operator for planet5
    cout << "Using the overloaded '-' operator for planet5:" << endl;
    planet5 = -planet1;
    cout << "The planet " << planet5.getPlanetName() << " is planet number: " << planet5.getPlanetNumber() << endl;
    cout << "It has " << planet5.getNumMoons() << " moons." << endl << endl;

    // Overloaded '+' operator for planet6
    cout << "Using the overloaded '+' operator for planet6:" << endl;
    planet6 = +planet1;
    cout << "The planet " << planet6.getPlanetName() << " is planet number: " << planet6.getPlanetNumber() << endl;
    cout << "It has " << planet6.getNumMoons() << " moons." << endl << endl;

    cout << "Thank you for using the program!" << endl;
    system("pause");
    return 0;
}

