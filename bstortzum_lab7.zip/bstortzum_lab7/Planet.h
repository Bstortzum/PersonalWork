// Brian Stortzum
// 04/08/2025
// IS-241 Lab 7 � Object Oriented Advanced

#ifndef PLANET_H
#define PLANET_H

#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

const int PLANET_NAME_SIZE = 8;

class Planet {
private:
    char planetName[PLANET_NAME_SIZE];
    int planetNumber; 
    int numMoons;

    // Private helper function prototypes.
    void setPlanetNumberFromName();
    void setNumMoonsFromPlanetNumber();
    void setNameFromPlanetNumber();

public:
    // Constructors (definitions are provided in Planet_Builder.cpp).
    Planet();
    Planet(const char* pName);

    // Get function prototypes.
    const char* getPlanetName() const;
    int getPlanetNumber() const;
    int getNumMoons() const;

    // Operator overload declarations.
    Planet& operator++();     // Prefix ++ operator
    Planet operator++(int);   // Postfix ++ operator
    Planet operator=(const Planet& rhs);
    Planet operator-() const; // Unary -
    Planet operator+() const; // Unary +

    // Friend declarations for stream insertion and extraction operators.
    friend ostream& operator<<(ostream& out, const Planet& p);
    friend istream& operator>>(istream& in, Planet& p);
};

#endif