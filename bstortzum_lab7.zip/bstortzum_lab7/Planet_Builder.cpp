// Brian Stortzum
// 04/08/2025
// IS-241 Lab 7 � Object Oriented Advanced

#include "Planet.h"
#include <iostream>
#include <cstring>
using namespace std;

// Private Member Functions
void Planet::setPlanetNumberFromName()
{
    if (strcmp(planetName, "Mercury") == 0)
        planetNumber = 1;
    else if (strcmp(planetName, "Venus") == 0)
        planetNumber = 2;
    else if (strcmp(planetName, "Earth") == 0)
        planetNumber = 3;
    else if (strcmp(planetName, "Mars") == 0)
        planetNumber = 4;
    else if (strcmp(planetName, "Jupiter") == 0)
        planetNumber = 5;
    else if (strcmp(planetName, "Saturn") == 0)
        planetNumber = 6;
    else if (strcmp(planetName, "Uranus") == 0)
        planetNumber = 7;
    else if (strcmp(planetName, "Neptune") == 0)
        planetNumber = 8;
    else
    {
        strcpy_s(planetName, PLANET_NAME_SIZE, "None");
        planetNumber = 0;
    }
}

void Planet::setNumMoonsFromPlanetNumber()
{
    switch (planetNumber)
    {
    case 1: numMoons = 0; 
        break;
    case 2: numMoons = 0; 
        break;
    case 3: numMoons = 1; 
        break;
    case 4: numMoons = 2; 
        break;
    case 5: numMoons = 95; 
        break;
    case 6: numMoons = 146; 
        break;
    case 7: numMoons = 28; 
        break;
    case 8: numMoons = 16; 
        break;
    default: numMoons = 0; 
        break;
    }
}

void Planet::setNameFromPlanetNumber()
{
    switch (planetNumber)
    {
    case 1: strcpy_s(planetName, PLANET_NAME_SIZE, "Mercury"); 
        break;
    case 2: strcpy_s(planetName, PLANET_NAME_SIZE, "Venus"); 
        break;
    case 3: strcpy_s(planetName, PLANET_NAME_SIZE, "Earth"); 
        break;
    case 4: strcpy_s(planetName, PLANET_NAME_SIZE, "Mars"); 
        break;
    case 5: strcpy_s(planetName, PLANET_NAME_SIZE, "Jupiter"); 
        break;
    case 6: strcpy_s(planetName, PLANET_NAME_SIZE, "Saturn"); 
        break;
    case 7: strcpy_s(planetName, PLANET_NAME_SIZE, "Uranus"); 
        break;
    case 8: strcpy_s(planetName, PLANET_NAME_SIZE, "Neptune"); 
        break;
    default: strcpy_s(planetName, PLANET_NAME_SIZE, "None"); 
        break;
    }
}

// Constructors
Planet::Planet()
{
    strcpy_s(planetName, PLANET_NAME_SIZE, "None");
    setPlanetNumberFromName();
    setNumMoonsFromPlanetNumber();
}

Planet::Planet(const char* pName)
{
    strncpy_s(planetName, PLANET_NAME_SIZE, pName, PLANET_NAME_SIZE - 1);
    planetName[PLANET_NAME_SIZE - 1] = '\0';
    setPlanetNumberFromName();
    setNumMoonsFromPlanetNumber();
}

// Get Functions
const char* Planet::getPlanetName() const {
    return planetName;
}

int Planet::getPlanetNumber() const {
    return planetNumber;
}

int Planet::getNumMoons() const {
    return numMoons;
}

// Operator Overloads
Planet& Planet::operator++() 
{ 
    if (planetNumber < 1 || planetNumber >= 8)
        planetNumber = 1;
    else
        planetNumber++;
    setNameFromPlanetNumber();
    setNumMoonsFromPlanetNumber();
    return *this;
}
// Postfix ++
Planet Planet::operator++(int) 
{
    Planet temp = *this;
    ++(*this);
    return temp;
}

Planet Planet::operator=(const Planet& rhs) 
{
    if (this != &rhs) 
    {
        strncpy_s(planetName, PLANET_NAME_SIZE, rhs.planetName, PLANET_NAME_SIZE - 1);
        planetName[PLANET_NAME_SIZE - 1] = '\0';
        setPlanetNumberFromName();
        setNumMoonsFromPlanetNumber();
    }
    return *this;
}

Planet Planet::operator-() const 
{
    return Planet("Mercury");
}

Planet Planet::operator+() const 
{
    return Planet("Neptune");
}

// Overloaded stream insertion operator.
ostream& operator<<(ostream& out, const Planet& p)
{
    out << "Planet: " << p.planetName << "\n"
        << "Planet Number: " << p.planetNumber << "\n"
        << "Number of Moons: " << p.numMoons << "\n";
    return out;
}

// Overloaded stream extraction operator.
istream& operator>>(istream& in, Planet& p)
{
    cout << "Enter the name of the planet: ";
    in >> p.planetName;
    p.planetName[PLANET_NAME_SIZE - 1] = '\0';
    p.setPlanetNumberFromName();
    p.setNumMoonsFromPlanetNumber();
    return in;
}
