// Brian Stortzum
// 04/29/2025
// This Program goes over my knowlegde over linked lists
#include "Employ_bstortzum_lab9.h"
#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdlib>
using namespace std;

// Default Constructor
Employees::Employees()
{
    setFirstName("");
    setLastName("");
    setDaysWorked(0);
    setUnitsSold(0);
}

Employees::Employees(const char* fName, const char* lName, int days, int sold)
{
    setFirstName(fName);
    setLastName(lName);
    setDaysWorked(days);
    setUnitsSold(sold);
}

// Setter for first name
void Employees::setFirstName(const char* fName)
{
    strncpy_s(firstName, fName, EMP_NAME_SIZE - 1);
    firstName[EMP_NAME_SIZE - 1] = '\0';
}

// Setter for last name
void Employees::setLastName(const char* lName)
{
    strncpy_s(lastName, lName, EMP_NAME_SIZE - 1);
    lastName[EMP_NAME_SIZE - 1] = '\0';
}

// Setter for days worked
void Employees::setDaysWorked(int days)
{
    daysWorked = days;
}

// Setter for units sold
void Employees::setUnitsSold(int sold)
{
    unitsSold = sold;
}

// Getter for first name
const char* Employees::getFirstName() const
{
    return firstName;
}

// Getter for last name
const char* Employees::getLastName() const
{
    return lastName;
}

// Getter for days worked
int Employees::getDaysWorked() const
{
    return daysWorked;
}

// Getter for units sold
int Employees::getUnitsSold() const
{
    return unitsSold;
}

// This caluates the average units sold per employee and returns as a double
double Employees::avgUnitSold() const
{
    int empDays = getDaysWorked();
    int empSold = getUnitsSold();
    if (empDays == 0)
        return 0.0;
    return static_cast<double>(empSold) / empDays;
}

// This Display the list using overload operators
ostream& operator<<(ostream& out, const Employees& e)
{
    double avg = e.avgUnitSold();
    out << "Employee: " << e.getFirstName() << " " << e.getLastName() 
        << " worked " << e.getDaysWorked() << " days and sold " << e.getUnitsSold()
        << " units for an average of " << fixed << setprecision(2) << avg
        << " units per day.";
    return out;
}
