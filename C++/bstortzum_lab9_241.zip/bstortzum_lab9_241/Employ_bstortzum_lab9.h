// Brian Stortzum
// 04/29/2025
// This Program goes over my knowlegde over linked lists
#ifndef EMPLOY_BSTORTZUM_LAB9
#define EMPLOY_BSTORTZUM_LAB9

#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdlib>
using namespace std;

// Declared Constants
const int EMP_NAME_SIZE = 24;

// Prototype Functions
void displayTitle();
ifstream openInFile();

class Employees
{
private:
    char firstName[EMP_NAME_SIZE] = " ";
    char lastName[EMP_NAME_SIZE] = " ";
    int daysWorked = 0;
    int unitsSold = 0;

    double avgUnitSold() const;
public:
    // Constructors
    Employees();

    // This constructor uses the setter methods only
    Employees(const char* fName, const char* lName, int days, int sold);

    // Setter method
    void setFirstName(const char* fName);
    void setLastName(const char* lName);
    void setDaysWorked(int days);
    void setUnitsSold(int sold);

    // Getter method
    const char* getFirstName() const;
    const char* getLastName() const;
    int getDaysWorked() const;
    int getUnitsSold() const;

    //Display list using overload operators
    friend ostream& operator<<(ostream& out, const Employees& e);
};
#endif