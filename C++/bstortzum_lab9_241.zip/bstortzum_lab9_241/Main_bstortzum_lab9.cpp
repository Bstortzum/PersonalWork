// Brian Stortzum
// 04/29/2025
// This Program goes over my knowlegde over linked lists
#include "Employ_bstortzum_lab9.h"
#include <iostream>
#include <iomanip>
#include <list>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <string>
using namespace std;

// Prototype Functions
void displayTitle();
ifstream openInFile();
void inputData(list<Employees>& empList);
void displayEmp(const list<Employees>& empList);
void findEmp(list<Employees>& empList);

int main()
{
    // Set fixed output formatting for decimals.
    cout << fixed << setprecision(2) << showpoint;

    // Displays title
    displayTitle();

    // Creates a empty list
    list<Employees>empData;

    // Read employee data from file.
    inputData(empData);

    // Display the sorted employee information.
    displayEmp(empData);

    // Find the employee with the last name "Girma"
    findEmp(empData);

    // Clear the list.
    empData.clear();

    cout << "\nThank you for using the program\n";
    system("pause");
    return 0;
}

// Displays the program title and introduction.
void displayTitle()
{
    cout << "IS-241 Lab 9 - Linked Lists\n";
    cout << "This program reads an employee file and displays the data sorted by last name.\n\n";
}

// Prompts the user to enter the file name and opens the file.
ifstream openInFile()
{
    string fName;
    ifstream fHandle;
    do
    {
        cout << "Enter input file name and path: ";
        getline(cin, fName);
        fHandle.open(fName);
        if (!fHandle)
        {
            cout << "Error - File could not be found. Please Reenter\n\n";
        }
    } while (!fHandle);

    return fHandle;

}

// Reads employee data from the input file and populates the vector.
void inputData(list<Employees>& empList)
{
    ifstream inFile = openInFile();
    char tempFirst[EMP_NAME_SIZE];
    char tempLast[EMP_NAME_SIZE];
    char NumDaysSold[EMP_NAME_SIZE];
    int days, sold;

    while (inFile.getline(tempFirst, EMP_NAME_SIZE))
    {
        inFile.getline(tempLast, EMP_NAME_SIZE);
        inFile.getline(NumDaysSold, EMP_NAME_SIZE);
        days = atoi(NumDaysSold);
        inFile.getline(NumDaysSold, EMP_NAME_SIZE);
        sold = atoi(NumDaysSold);

        Employees emp(tempFirst, tempLast, days, sold);
        
        // This gives value to the list
        if (empList.empty())
        {
            empList.push_back(emp);
        }
        else
        {
            auto it = empList.begin();

            // This Looks if the value is lower then it sets in the front
            if (strcmp(emp.getLastName(), it->getLastName()) < 0) // Sends it to access the getlastname for dereference
            {
                empList.push_front(emp);
            }
            else
            {
                bool flag = true;

                while (flag)
                {
                    if (strcmp(emp.getLastName(), it->getLastName()) < 0) // Insert employees by there last name so it can sort it by last name alphabetical
                    {
                        empList.insert(it, emp);
                        flag = false;
                    }
                    ++it;
                    if (it == empList.end()) // If its the value greater then the last value, will be added to the end
                    {
                        empList.push_back(emp);
                        flag = false;
                    }
                }
            }
        }
    }

    inFile.close();
    cout << "\nThe number of Employees read is: " << empList.size() << "\n\n";
}



// Displays each employee's information using a range-based for loop.
void displayEmp(const list<Employees>& empList)
{
    for (const Employees& emp : empList)
    {
        cout << emp << endl;
    }
}

// Searches for an employee with the last name "Girma". If found and if that employee's units sold is 99,
void findEmp(list<Employees>& empList)
{
    bool found = false;
    for (Employees& emp : empList)
    {
        if (strcmp(emp.getLastName(), "Girma") == 0)
        {
            if (emp.getUnitsSold() == 99)
            {
                emp.setUnitsSold(106);
                cout << "\nUpdated " << emp.getFirstName() << " " << emp.getLastName() << "'s units sold from 99 to " << emp.getUnitsSold() << ".\n";
            }
            found = true;
        }
    }
    if (found) // This is for if the function above finds Girma
    {
        cout << "\nAfter update:\n";
        displayEmp(empList);
    }
    else
    {
        cout << "\nError: No employee with last name 'Girma' found.\n";
    }
}
