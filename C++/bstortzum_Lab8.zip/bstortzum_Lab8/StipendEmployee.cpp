//Brian Stortzum
// 04/22/2025
// This shows my knowlegde on Inheritance and Polymorphism to end the section on OOP
#include "StipendEmployee.h"
#include <iostream>
#include <iomanip>
using namespace std;

// Initialize with stipend info
StipendEmployee::StipendEmployee(int id, const std::string& name, double amount, double hours) : Employee(id, name), totalAmount(amount), totalHours(hours) 
{
    setTotalAmount(amount);
    setTotalHours(hours);
}

// Setters
void StipendEmployee::setTotalAmount(double amount) 
{
    totalAmount = amount;
}

void StipendEmployee::setTotalHours(double hours) 
{
    totalHours = hours;
}

// Getters
double StipendEmployee::getTotalAmount() const 
{
    return totalAmount;
}

double StipendEmployee::getTotalHours() const 
{
    return totalHours;
}

void StipendEmployee::printPay() {
    double weeks = totalHours / 40.0;
    double weeklyPay = totalAmount / weeks;
    cout << "The pay for the stipend employee " << getEmployeeName() << " with the ID number " << getEmployeeId() << " is $" << fixed << setprecision(2) << weeklyPay << endl;
}
