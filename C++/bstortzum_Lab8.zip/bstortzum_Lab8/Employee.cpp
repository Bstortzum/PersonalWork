//Brian Stortzum
// 04/22/2025
// This shows my knowlegde on Inheritance and Polymorphism to end the section on OOP
#include "Employee.h"
using namespace std;

// Initialize ID and name
Employee::Employee(int id, const string& name) : employeeId(id), employeeName(name) 
{
}

// Setters
void Employee::setEmployeeId(int id) 
{ 
    employeeId = id; 
}
void Employee::setEmployeeName(const string& name) 
{ 
    employeeName = name; 
}

// Getters
int Employee::getEmployeeId() const 
{ 
    return employeeId; 
}
const string& Employee::getEmployeeName() const 
{ 
    return employeeName; 
}