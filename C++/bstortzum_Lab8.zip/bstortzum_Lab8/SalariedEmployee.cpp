//Brian Stortzum
// 04/22/2025
// This shows my knowlegde on Inheritance and Polymorphism to end the section on OOP
#include "SalariedEmployee.h"
#include <iostream>
#include <iomanip>
using namespace std;

SalariedEmployee::SalariedEmployee(int id, const string& name, double salary) : Employee(id, name), annualSalary(salary) 
{
    setAnnualSalary(salary);
}

void SalariedEmployee::setAnnualSalary(double salary) 
{
    annualSalary = salary;
}

double SalariedEmployee::getAnnualSalary() const 
{
    return annualSalary;
}

void SalariedEmployee::printPay() 
{
    double weeklyPay = annualSalary / 52.0;
    cout << "The pay for the salary employee " << getEmployeeName() << " with the ID number " << getEmployeeId() << " is $" << fixed << setprecision(2) << weeklyPay << endl;
}
