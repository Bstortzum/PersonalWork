//Brian Stortzum
// 04/22/2025
// This shows my knowlegde on Inheritance and Polymorphism to end the section on OOP
#ifndef SALARIEDEMPLOYEE_H
#define SALARIEDEMPLOYEE_H

#include "Employee.h"
using namespace std;

// Employee with fixed annual salary
class SalariedEmployee : public Employee 
{
private:
    double annualSalary;  // Total yearly salary

public:
    // Constructor: sets base Employee and salary
    SalariedEmployee(int id, const string& name, double salary);

    // Accessor and mutator for salary
    double getAnnualSalary() const;
    void setAnnualSalary(double salary);

    // Calculate and display weekly pay
    void printPay() override;
};

#endif