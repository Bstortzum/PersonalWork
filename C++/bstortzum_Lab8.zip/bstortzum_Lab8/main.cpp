//Brian Stortzum
// 04/22/2025
// This shows my knowlegde on Inheritance and Polymorphism to end the section on OOP

#include <iostream>
#include <vector>
#include <iostream>
#include <iomanip>
#include "Employee.h"
#include "HourlyEmployee.h"
#include "SalariedEmployee.h"
#include "StipendEmployee.h"
using namespace std;

// Prototype Functions
void displayTitle();
int getValidatedInt(int min, int max);
double getValidatedDouble(double min);
void getInput(vector<Employee*>& Ve);
void printList(const vector<Employee*>& Ve);

// This Displays title
void displayTitle() 
{
    cout << right << setw(50) << "IS-241 Lab 8 - Inheritance and Polymorphism" << endl;
    cout << right << setw(50) << "Welcome to IS-241 Employee Weekly Pay Program" << endl;
}

// Continue prompting until valid integer is entered
int getValidatedInt(int min, int max) 
{
    int value;
    while (true) 
    {
        if (!(cin >> value) || value < min || value > max) 
        {
            cout << "Error - Invalid entry. Enter a value between " << min << " and " << max << ": ";
            cin.clear();
            cin.ignore();
        }
        else 
        {
            cin.ignore();
            return value;
        }
    }
}

// Continue prompting until valid double is entered
double getValidatedDouble(double min)
{
    double value;
    while (true)
    {
        if (!(cin >> value) || value <= min)
        {
            cout << "Error � Invalid entry. Enter a value greater than " << min << ": ";
            cin.clear();
            cin.ignore();
        }
        else
        {
            cin.ignore();
            return value;
        }
    }
}

// Add employees based on user choice until quit
void getInput(vector<Employee*>& Ve) 
{
    int choice;
    do
    {
        cout << "\n1. Hourly Employee\n"
            "2. Salaried Employee\n"
            "3. Stipend Employee\n"
            "4. Quit\n"
            << "Enter choice: ";
        cin >> choice;
        
        while (choice < 1 || choice > 4)
        {
            cout << "Error - Invaild Entry. Please Reenter Number choice!";
            cout << "Enter choice: ";
            cin >> choice;
        }

        switch (choice) 
        {
        case 1: 
        {  // Hourly
            double hours;
            int id;
            double rate;
            string name;

            cout << "Enter ID (100000-999999): ";
            id = getValidatedInt(100000, 999999);
            
            cout << "\nEnter name: ";
            getline(cin, name);
            
            cout << "\nEnter hours worked: ";
            hours = getValidatedDouble(0);
            
            cout << "\nEnter pay rate: ";
            rate = getValidatedDouble(0);
            
            Ve.push_back(new HourlyEmployee(id, name, hours, rate));
            
            break;
        }
        case 2: 
        {  // Salaried
            int id;
            double salary;
            string name;

            cout << "\nEnter ID (100000-999999): ";
            id = getValidatedInt(100000, 999999);
           
            cout << "\nEnter name: ";
            getline(cin, name);
            
            cout << "\nEnter annual salary: ";
            salary = getValidatedDouble(0);
            
            Ve.push_back(new SalariedEmployee(id, name, salary));
           
            break;
        }
        case 3: 
        {  // Stipend
            int id;
            double hours;
            double amount;
            string name;
            
            cout << "\nEnter ID (100000-999999): ";
            id = getValidatedInt(100000, 999999);
            
            cout << "\nEnter name: ";
            getline(cin, name);
            
            cout << "\nEnter total stipend amount: ";
            amount = getValidatedDouble(0);
            
            cout << "\nEnter total contract hours: ";
            hours = getValidatedDouble(0);
            
            Ve.push_back(new StipendEmployee(id, name, amount, hours));
            
            break;
        }
        case 4:  // Quit
            
            cout << "Exiting input menu...\n";
            
            break;
        }

        cout << endl;
    } while (choice != 4);
}

// Loop through and call printPay() on each employee
void printList(const vector<Employee*>& Ve) 
{
    cout << "\nOutput Report:\n";
    for (auto e : Ve) 
    {
        e->printPay();
    }
}

int main()
{
    // Store employee pointers
    vector<Employee*> employees;

    displayTitle();

    getInput(employees);

    printList(employees);
    
    // Delete allocated memory
    for (auto ptr : employees)
        delete ptr;
    
    cout << "\n Thanks For using my program!" << endl;
    system("pause");
    return 0;
}