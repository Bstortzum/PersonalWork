//Brian Stortzum
// 04/22/2025
// This shows my knowlegde on Inheritance and Polymorphism to end the section on OOP
#include "HourlyEmployee.h"
#include <iostream>
#include <iomanip>
using namespace std;

HourlyEmployee::HourlyEmployee(int id, const string& name, double hours, double rate) : Employee(id, name), hoursWorked(hours), payRate(rate) 
{
    setHoursWorked(hours);
    setPayRate(rate);
}

// Setter functions
void HourlyEmployee::setHoursWorked(double hours) 
{
    hoursWorked = hours;
}

void HourlyEmployee::setPayRate(double rate) 
{
    payRate = rate;
}

// Getter functions
double HourlyEmployee::getHoursWorked() const 
{
    return hoursWorked;
}

double HourlyEmployee::getPayRate() const 
{
    return payRate;
}

// Display Hourly Employee
void HourlyEmployee::printPay() 
{
    double weeklyPay = hoursWorked * payRate;
    cout << "The pay for the hourly employee " << getEmployeeName() << " with the ID number " << getEmployeeId() << " is $" << fixed << setprecision(2) << weeklyPay << endl;
}
