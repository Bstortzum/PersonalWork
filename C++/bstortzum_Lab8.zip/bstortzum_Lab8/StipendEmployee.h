//Brian Stortzum
// 04/22/2025
// This shows my knowlegde on Inheritance and Polymorphism to end the section on OOP
#ifndef STIPENDEMPLOYEE_H
#define STIPENDEMPLOYEE_H

#include "Employee.h"
using namespace std;

// Employee paid a lump-sum stipend over contract hours
class StipendEmployee : public Employee 
{
private:
    double totalAmount;   // Total stipend amount
    double totalHours;    // Contracted hours

public:
    // Constructor: sets base and stipend details
    StipendEmployee(int id, const string& name, double amount, double hours);

    // Accessors and mutators for amount and hours
    double getTotalAmount() const;
    void setTotalAmount(double amount);
    double getTotalHours() const;
    void setTotalHours(double hours);

    // Calculate and display weekly pay
    void printPay() override;
};

#endif
