//Brian Stortzum
// 04/22/2025
// This shows my knowlegde on Inheritance and Polymorphism to end the section on OOP

#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
using namespace std;

// Base class for employees: stores ID and name
class Employee 
{
private:
    int employeeId;           // unique employee ID
    string employeeName;      // employee's name

public:
    Employee(int id, const string& name);   // initialize ID and name
    virtual ~Employee() = default;           // default destructor

    int getEmployeeId() const;              // retrieve ID
    const string& getEmployeeName() const;  // retrieve name

    void setEmployeeId(int id);             // update ID
    void setEmployeeName(const string& name); // update name

    virtual void printPay() = 0;            // compute and display pay
};

#endif
