//Brian Stortzum
// 04/22/2025
// This shows my knowlegde on Inheritance and Polymorphism to end the section on OOP
#ifndef HOURLYEMPLOYEE_H
#define HOURLYEMPLOYEE_H

#include "Employee.h"
using namespace std;

// Employee paid by the hour
class HourlyEmployee : public Employee 
{
private:
    double hoursWorked;    // Hours worked in a week
    double payRate;        // Hourly pay rate

public:
    // Constructor: sets base Employee and hourly details
    HourlyEmployee(int id, const string& name, double hours, double rate);

    // Accessors and mutators for hours and rate
    double getHoursWorked() const;
    void setHoursWorked(double hours);
    double getPayRate() const;
    void setPayRate(double rate);

    // Calculate and display weekly pay
    void printPay() override;
};

#endif
